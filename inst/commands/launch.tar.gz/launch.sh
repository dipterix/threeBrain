#!/bin/bash

DIRECTORY=`dirname "$0"`
cd "$DIRECTORY"

# Rscript -e '{if(system.file("",package="servr")==""){utils::install.packages("servr",repos="https://cloud.r-project.org")};servr::httd(browser=TRUE)}'

# Use Python because linux and mac come with python

py_path=$(which python)

py_version=$($py_path -V 2>&1)

echo "-----------------------------------------------------------------------"
if echo $py_version | grep -q '^Python 3\.'; then
  echo "Python 3 detected at $py_path"
  echo "Please open the following address in your browser (Chrome recommended)"
  $py_path -m http.server 0
else
  echo "Python 2 detected at $py_path"
  echo "Please open the following address in your browser (Chrome recommended)"
  $py_path -m SimpleHTTPServer 0
fi
